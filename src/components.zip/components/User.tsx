import React, { useContext } from 'react'
import { myCotext } from './Context'
interface MyContextType {
    counter: number;
    increment: () => void;
}
const User = () => {
    const {counter,increment}=useContext(myCotext) as MyContextType

    console.log(counter)
  return (
    <>
    <div>User</div>
    <p>{counter}</p>
    <button onClick={increment}>increment</button>
    </>
  )
}

export default User