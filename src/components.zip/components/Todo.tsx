import React, { useContext, useEffect, useMemo, useRef, useState } from "react";
import { myCotext } from "./Context";

interface Props {
  handleChange: () => void;
  text: string;
  data: { text: string; id: number }[];
  addTodo: () => void;
  deleteUser: (id: number) => void;
  edituser: (item: any) => void;
  updateUser: () => void;
  isToggle: boolean;
}

const Todo = () => {
  const { handleChange, text, data, addTodo, deleteUser, edituser, updateUser, isToggle } =
    useContext(myCotext) as Props;

  const [number, setNumber] = useState(0);
  const count = useRef(0); 
  const [enterNumber,setenterNumber]=useState(0)

  const incrementBtn = () => {
    setNumber(number + 1);
  };

  const enterNumberHandle=(num:number)=>{
    console.log("hell usememo")
    return Math.pow(num,3)
  }
  const newdigit=useMemo(()=>enterNumberHandle(enterNumber),[enterNumber])   

  const generateOtp=()=>{
    let otp=0
    otp=Math.floor(Math.random()*9000)+1000

    console.log(otp)  }

  useEffect(() => {
    generateOtp()
    count.current=count.current+1
  }); 
  return (
    <div>
      <input
        type="text"
        value={text}
        onChange={handleChange}
        placeholder="adduser"
      />
      
      {isToggle ? 
        <button onClick={updateUser}>update</button> :
        <button onClick={addTodo}>adduser</button>
      }

      {data.map((item) => (
        <div key={item.id}>
          <p>{item.text}</p>
          <button onClick={() => deleteUser(item.id)}>delete</button>
          <button onClick={() => edituser(item)}>edit</button>
        </div>
      ))}
      <button onClick={incrementBtn}>kkk</button>

      <h1>{count.current}</h1>
      <br></br>
      <br></br>
      <br></br>
      <input type="number" placeholder="pleas enter number" value={enterNumber} onChange={(e:any)=>setenterNumber(e.target.value)}/>
      <br/>
      <p>{newdigit}</p>
    </div>
  );
};

export default Todo;
