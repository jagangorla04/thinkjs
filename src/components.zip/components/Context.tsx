import React, { createContext, useState } from "react";

export const myCotext = createContext({});
interface iprops {
  children: any;
}
const Context: React.FC<iprops> = ({ children }) => {
  const [counter, setCounter] = useState(0);
  const [data, setData] = useState<{ text: string; id: number }[]>([]);
  const [text, setText] = useState("");
  const [activeId, setActiveId] = useState(0);
  const [isToggle,setIsToggle]=useState(false)
  const addTodo = () => {
    const obj = {
      text: text,
      id: Date.now(),
    };
    setData((prev) => [...prev, obj]);
    setText("");
  };

  const deleteUser = (id: number) => {
    const filteruser = data.filter((item) => item.id !== id);
    setData(filteruser);
  };

  const updateUser=()=>{
    if(activeId !==null){
        const updateDate=data.map((item)=>item.id === activeId?{...item,text}:item)
    setData(updateDate)
    setActiveId(0)
    setText("")
    setIsToggle(false)
    }
   
  }

  const edituser = (item: { text: string; id: number }) => {
    setText(item.text);
    setActiveId(item.id);
    setIsToggle(true)
  };
  const handleChange = (e: any) => {
    setText(e.target.value);
  };
  const increment = () => {
    setCounter(counter + 1);
  };
  return (
    <myCotext.Provider
      value={{
        counter,
        increment,
        handleChange,
        text,
        data,
        addTodo,
        deleteUser,
        edituser,updateUser,isToggle
      }}
    >
      {children}
    </myCotext.Provider>
  );
};

export default Context;
